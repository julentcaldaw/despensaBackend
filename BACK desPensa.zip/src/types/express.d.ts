import type { UserRole } from "@prisma/client";

declare global {
    namespace Express {
        interface Request {
            user?: {
                id: number;
                email: string;
                username: string;
                role: UserRole;
            };
        }
    }
}

export { };

